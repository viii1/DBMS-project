﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Data.SqlClient;
using System.Xml.Linq;

public partial class Default2 : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.AppSettings["connection"]);
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            gridfill();
        }
    }
    public void gridfill()
    {
        SqlDataAdapter da = new SqlDataAdapter("select * from adminlogin", con);
        DataSet ds = new DataSet();
        da.Fill(ds);
        GridView1.DataSource = ds;
        GridView1.DataBind();
    }





    protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
    {
        GridView1.EditIndex = e.NewEditIndex;
        gridfill();

    }
    protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        GridView1.EditIndex = -1;
        gridfill();
    }
    protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        //string firstname = string.Empty;
        string lastname = string.Empty;
        //string loginid = string.Empty;
        string currentpassword = string.Empty;
        string newpassword = string.Empty;
        string retypepassword = string.Empty;
        string email = string.Empty;
        string mobile = string.Empty;

        //string name = string.Empty;
        //string lname = string.Empty;
        //TextBox tn = (TextBox)GridView1.Rows[e.RowIndex].FindControl("txtfn");
        //name = tn.Text;
        string name = string.Empty;

        string lname = string.Empty;
        TextBox tn = (TextBox)GridView1.Rows[e.RowIndex].FindControl("txtfn");
        name = tn.Text;

        TextBox tn1 = (TextBox)GridView1.Rows[e.RowIndex].FindControl("txtlastname");
        lastname = tn1.Text;

        TextBox tn2 = (TextBox)GridView1.Rows[e.RowIndex].FindControl("txtcurrentpassword");
        currentpassword = tn2.Text;


        TextBox tn3 = (TextBox)GridView1.Rows[e.RowIndex].FindControl("txtnewpassword");
        newpassword = tn3.Text;

        TextBox tn4 = (TextBox)GridView1.Rows[e.RowIndex].FindControl("txtretypepassword");
        retypepassword = tn4.Text;

        TextBox tn5 = (TextBox)GridView1.Rows[e.RowIndex].FindControl("txtemail");
        email = tn5.Text;

        TextBox tn6 = (TextBox)GridView1.Rows[e.RowIndex].FindControl("txtmobile");
        mobile = tn6.Text;




        Label lbl = (Label)GridView1.Rows[e.RowIndex].FindControl("lblloginid");
        lname = lbl.Text;
        SqlConnection con = new SqlConnection("SFRH\\SQLEXPRESS;database=kamal;integrated security=sspi");
        con.Open();
        SqlCommand cmd = new SqlCommand("update adminlogin set firstname='" + name + "',lastname='" + lastname + "',currentpassword='" + currentpassword + "',newpassword='" + newpassword + "',retypepassword='" + retypepassword + "',email='" + email + "',mobile='" + mobile + "' where loginid='" + lname + "'", con);
        cmd.ExecuteNonQuery();
        con.Close();
        GridView1.EditIndex = -1;
        gridfill();
        
    }
}
