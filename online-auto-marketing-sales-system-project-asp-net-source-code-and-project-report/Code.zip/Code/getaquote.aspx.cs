﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class Default2 : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.AppSettings["connection"]);
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        con.Open();
        SqlCommand cmd = new SqlCommand("insert into getquote values('" + TextBox1.Text + "','" + DropDownList1.SelectedItem.ToString() + "','" + DropDownList3.SelectedItem.ToString() + "','" + DropDownList4.SelectedItem.ToString() + "','" + DropDownList2.SelectedItem.ToString() + "','" + TextBox7.Text + "','" + TextBox8.Text + "','" + TextBox10.Text + "','" + TextBox9.Text + "','" + TextBox11.Text + "','" + TextBox12.Text + "','" + TextBox2.Text + "','" + TextBox13.Text + "','" + TextBox16.Text + "','" + TextBox15.Text + "')", con);
        cmd.ExecuteNonQuery();
        con.Close();

    }
    protected void TextBox15_TextChanged(object sender, EventArgs e)
    {

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        TextBox1.Text = "";
        TextBox7.Text = "";
        TextBox8.Text = "";
        TextBox10.Text = "";
        TextBox9.Text = "";
        TextBox11.Text = "";
        TextBox12.Text = "";
        TextBox2.Text = "";
        TextBox13.Text = "";
        TextBox16.Text = "";
        TextBox15.Text = "";
    }
}
