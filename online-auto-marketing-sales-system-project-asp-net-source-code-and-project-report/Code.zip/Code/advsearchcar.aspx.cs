﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class Default2 : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.AppSettings["connection"]);
    protected void Page_Load(object sender, EventArgs e)
    {
        //SqlCommand cmd = new SqlCommand("select * from advsearch",con);
        //SqlDataAdapter da = new SqlDataAdapter(cmd);
        
        //DataSet ds = new DataSet();
        //da.Fill(ds,"make");
        //DropDownList1.DataSource = ds;
        //DropDownList1.DataTextField = "make";
        //DropDownList1.DataBind();
        //Label3.Text = a.ToString();
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        //Response.Redirect();
    }
}
