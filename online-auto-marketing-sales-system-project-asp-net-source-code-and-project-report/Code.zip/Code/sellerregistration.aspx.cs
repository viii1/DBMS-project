﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Data.SqlClient;
using System.Xml.Linq;

public partial class Default2 : System.Web.UI.Page
{
    //SqlConnection con = new SqlConnection(ConfigurationManager.AppSettings["connection"]);
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        Response.Redirect("stratup.aspx");
    }
    protected void Button2_Click(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection("SFRH\\SQLEXPRESS;database=kamal;integrated security=sspi");  
        con.Open();
       // SqlCommand cmd = new SqlCommand("insert into sellers values('"+TextBox3.Text+"')",con);
        SqlCommand cmd = new SqlCommand("insert into Sellers values('" + Convert.ToInt32(TextBox1.Text) + "','" + TextBox3.Text + "','" + TextBox4.Text + "','" + TextBox5.Text + "','" + TextBox6.Text + "','" + TextBox7.Text + "','" + TextBox8.Text + "','" + TextBox10.Text + "','" + TextBox9.Text + "','" + TextBox11.Text + "','" + TextBox14.Text + "','" + TextBox13.Text + "','" + TextBox12.Text + "','" + TextBox2.Text + "','" + TextBox15.Text + "')",con);
        cmd.ExecuteNonQuery();
        con.Close();
    }
}
